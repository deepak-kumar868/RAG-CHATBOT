from functools import lru_cache

from openai import AzureOpenAI, OpenAI

from .config import settings


@lru_cache(maxsize=1)
def get_client() -> OpenAI:
    """Azure OpenAI if AZURE_OPENAI_ENDPOINT is set, otherwise OpenAI."""
    if settings.azure_endpoint:
        return AzureOpenAI(
            api_key=settings.azure_api_key,
            azure_endpoint=settings.azure_endpoint,
            api_version=settings.azure_api_version,
        )
    return OpenAI(api_key=settings.openai_api_key)


def embed(texts: list[str], batch_size: int = 64) -> list[list[float]]:
    """Embed texts with ada-002, batched, preserving order."""
    client = get_client()
    out: list[list[float]] = []
    for i in range(0, len(texts), batch_size):
        batch = [t.replace("\n", " ") for t in texts[i : i + batch_size]]
        resp = client.embeddings.create(model=settings.embedding_model, input=batch)
        out.extend(d.embedding for d in sorted(resp.data, key=lambda d: d.index))
    return out
