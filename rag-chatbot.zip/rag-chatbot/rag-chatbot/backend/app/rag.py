"""RAG pipeline: rewrite query -> cross-lingual retrieve -> stream an English answer."""
import json
import logging
from collections.abc import Iterator

from .config import settings
from .llm import embed, get_client
from .vectorstore import search

log = logging.getLogger(__name__)

# Keep only the last few turns so the prompt stays small.
MAX_HISTORY_TURNS = 6

REWRITE_PROMPT = """You prepare search queries for a knowledge base whose documents are mostly in Spanish.
Given the chat history and the user's latest question, return JSON with two keys:
- "standalone_en": the latest question rewritten in English as a self-contained question (resolve pronouns and references using the history).
- "search_es": the same question translated into Spanish, phrased the way it would appear in a Spanish document.
Return JSON only."""

ANSWER_PROMPT = """You are a helpful assistant that answers questions using a knowledge base.
The context excerpts are numbered and are usually written in Spanish.

Rules:
- ALWAYS reply in English, even if the question or the context is in Spanish.
- Use ONLY the information in the context. If the context does not contain the answer, say you could not find it in the provided documents; do not guess.
- Translate the relevant information faithfully into English. Keep official Spanish names, form names and acronyms in their original form, with an English gloss in parentheses on first use.
- Cite the excerpts you used with their numbers in square brackets, e.g. [1] or [2][3].
- Be concise and well structured; use bullet points for steps or lists."""


def rewrite_query(question: str, history: list[dict]) -> tuple[str, str]:
    """Return (english_standalone_question, spanish_search_query). Falls back to the raw question."""
    turns = history[-MAX_HISTORY_TURNS * 2 :]
    transcript = "\n".join(f"{m['role']}: {m['content']}" for m in turns)
    try:
        resp = get_client().chat.completions.create(
            model=settings.chat_model,
            temperature=0,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": REWRITE_PROMPT},
                {"role": "user", "content": f"Chat history:\n{transcript or '(none)'}\n\nLatest question: {question}"},
            ],
        )
        data = json.loads(resp.choices[0].message.content)
        return data.get("standalone_en") or question, data.get("search_es") or question
    except Exception:
        log.exception("Query rewrite failed; using the raw question")
        return question, question


def retrieve(question: str, history: list[dict]) -> tuple[str, list[dict]]:
    """Embed both the English and Spanish forms of the query, so English questions find Spanish text."""
    standalone, spanish = rewrite_query(question, history)
    queries = [standalone] if standalone == spanish else [standalone, spanish]
    hits = search(embed(queries), settings.top_k)
    return standalone, hits


def _format_context(hits: list[dict]) -> str:
    blocks = []
    for i, h in enumerate(hits, 1):
        loc = f", page {h['page']}" if h.get("page") else ""
        blocks.append(f"[{i}] (source: {h['source']}{loc})\n{h['text']}")
    return "\n\n".join(blocks)


def stream_answer(question: str, history: list[dict]) -> Iterator[dict]:
    """Yield events: {'type': 'sources'|'token'|'done'|'error', ...}."""
    try:
        standalone, hits = retrieve(question, history)
        yield {
            "type": "sources",
            "query": standalone,
            "sources": [
                {
                    "n": i,
                    "source": h["source"],
                    "page": h.get("page") or None,
                    "score": round(1 - h["distance"], 3),  # cosine similarity
                    "text": h["text"],
                }
                for i, h in enumerate(hits, 1)
            ],
        }

        if not hits:
            yield {"type": "token", "text": "I couldn't find anything in the knowledge base. Please upload some documents first."}
            yield {"type": "done"}
            return

        messages = [{"role": "system", "content": ANSWER_PROMPT}]
        messages += history[-MAX_HISTORY_TURNS * 2 :]
        messages.append(
            {
                "role": "user",
                "content": f"Context:\n{_format_context(hits)}\n\nQuestion: {standalone}\n\nAnswer in English.",
            }
        )
        stream = get_client().chat.completions.create(
            model=settings.chat_model, temperature=0.2, messages=messages, stream=True
        )
        for event in stream:
            if not event.choices:  # Azure sends a leading chunk with no choices
                continue
            delta = event.choices[0].delta.content
            if delta:
                yield {"type": "token", "text": delta}
        yield {"type": "done"}
    except Exception as e:  # surface to the UI instead of dropping the stream
        log.exception("Chat failed")
        yield {"type": "error", "message": str(e)}
