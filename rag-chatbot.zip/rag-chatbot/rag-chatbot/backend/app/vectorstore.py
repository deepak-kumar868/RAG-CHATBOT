"""Thin wrapper around a local, persistent ChromaDB collection.

Embeddings are computed by us (ada-002) and passed in explicitly, so Chroma
never needs its own embedding function.
"""
import hashlib
from functools import lru_cache

import chromadb

from .config import settings
from .ingestion import chunk_document
from .llm import embed


@lru_cache(maxsize=1)
def get_collection():
    client = chromadb.PersistentClient(path=settings.chroma_dir)
    return client.get_or_create_collection(
        name=settings.collection_name,
        metadata={"hnsw:space": "cosine"},
    )


def add_document(filename: str, data: bytes) -> int:
    """Chunk, embed and store a file. Re-uploading a filename replaces the old version."""
    chunks = chunk_document(filename, data)
    if not chunks:
        raise ValueError("No extractable text found (scanned PDFs need OCR first).")

    col = get_collection()
    col.delete(where={"source": filename})

    doc_id = hashlib.sha1(data).hexdigest()[:12]
    embeddings = embed([c.text for c in chunks])
    col.add(
        ids=[f"{doc_id}:{i}" for i in range(len(chunks))],
        documents=[c.text for c in chunks],
        embeddings=embeddings,
        metadatas=[{"source": filename, "page": c.page, "chunk": i} for i, c in enumerate(chunks)],
    )
    return len(chunks)


def delete_document(filename: str) -> None:
    get_collection().delete(where={"source": filename})


def list_documents() -> list[dict]:
    res = get_collection().get(include=["metadatas"])
    counts: dict[str, int] = {}
    for m in res["metadatas"] or []:
        counts[m["source"]] = counts.get(m["source"], 0) + 1
    return [{"source": s, "chunks": n} for s, n in sorted(counts.items())]


def search(query_embeddings: list[list[float]], top_k: int) -> list[dict]:
    """Query with one or more embeddings; merge by chunk id keeping the best distance."""
    col = get_collection()
    if col.count() == 0:
        return []
    res = col.query(
        query_embeddings=query_embeddings,
        n_results=min(top_k, col.count()),
        include=["documents", "metadatas", "distances"],
    )
    best: dict[str, dict] = {}
    for q in range(len(query_embeddings)):
        for id_, doc, meta, dist in zip(
            res["ids"][q], res["documents"][q], res["metadatas"][q], res["distances"][q]
        ):
            if id_ not in best or dist < best[id_]["distance"]:
                best[id_] = {"id": id_, "text": doc, "distance": dist, **meta}
    return sorted(best.values(), key=lambda r: r["distance"])[:top_k]
