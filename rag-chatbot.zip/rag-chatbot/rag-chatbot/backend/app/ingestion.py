"""Load documents (PDF, DOCX, TXT/MD, HTML) and split them into chunks."""
import io
import re
from dataclasses import dataclass
from pathlib import Path

from bs4 import BeautifulSoup
from docx import Document
from pypdf import PdfReader

from .config import settings

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md", ".html", ".htm"}


@dataclass
class Chunk:
    text: str
    page: int  # 1-based page for PDFs, 0 when the format has no pages


def _decode(data: bytes) -> str:
    for enc in ("utf-8", "utf-8-sig", "latin-1"):  # Spanish files are often latin-1
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="ignore")


def load_pages(filename: str, data: bytes) -> list[tuple[int, str]]:
    """Return [(page_number, text)] for a file. page_number is 0 for non-paged formats."""
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        reader = PdfReader(io.BytesIO(data))
        return [(i + 1, page.extract_text() or "") for i, page in enumerate(reader.pages)]
    if ext == ".docx":
        doc = Document(io.BytesIO(data))
        parts = [p.text for p in doc.paragraphs]
        for table in doc.tables:
            for row in table.rows:
                parts.append(" | ".join(c.text.strip() for c in row.cells))
        return [(0, "\n".join(parts))]
    if ext in {".html", ".htm"}:
        soup = BeautifulSoup(_decode(data), "html.parser")
        for tag in soup(["script", "style", "nav", "footer"]):
            tag.decompose()
        return [(0, soup.get_text("\n"))]
    if ext in {".txt", ".md"}:
        return [(0, _decode(data))]
    raise ValueError(f"Unsupported file type: {ext or filename}")


def _clean(text: str) -> str:
    text = text.replace("\x00", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_text(text: str, size: int, overlap: int) -> list[str]:
    """Greedy splitter that prefers paragraph, then sentence, then word boundaries."""
    text = _clean(text)
    if not text:
        return []
    chunks: list[str] = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + size, n)
        if end < n:
            window = text[start:end]
            # look for the best boundary in the back half of the window
            floor = len(window) // 2
            for sep in ("\n\n", "\n", ". ", "? ", "! ", "; ", " "):
                idx = window.rfind(sep, floor)
                if idx != -1:
                    end = start + idx + len(sep)
                    break
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= n:
            break
        start = max(end - overlap, start + 1)
    return chunks


def chunk_document(filename: str, data: bytes) -> list[Chunk]:
    chunks: list[Chunk] = []
    for page, text in load_pages(filename, data):
        for piece in split_text(text, settings.chunk_size, settings.chunk_overlap):
            chunks.append(Chunk(text=piece, page=page))
    return chunks
