import json
import logging
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from . import rag, vectorstore
from .ingestion import SUPPORTED_EXTENSIONS

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="Spanish-KB RAG Chatbot")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class Message(BaseModel):
    role: str  # "user" | "assistant"
    content: str


class ChatRequest(BaseModel):
    question: str
    history: list[Message] = []


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/documents")
def documents():
    return vectorstore.list_documents()


@app.post("/ingest")
async def ingest(files: list[UploadFile] = File(...)):
    results = []
    for f in files:
        name = Path(f.filename or "").name
        ext = Path(name).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            results.append({"source": name, "ok": False, "error": f"Unsupported type '{ext}'"})
            continue
        try:
            n = vectorstore.add_document(name, await f.read())
            results.append({"source": name, "ok": True, "chunks": n})
        except Exception as e:
            results.append({"source": name, "ok": False, "error": str(e)})
    return results


@app.delete("/documents/{source}")
def delete_document(source: str):
    if not any(d["source"] == source for d in vectorstore.list_documents()):
        raise HTTPException(404, "Document not found")
    vectorstore.delete_document(source)
    return {"deleted": source}


@app.post("/chat/stream")
def chat_stream(req: ChatRequest):
    """Server-Sent Events: one `sources` event, many `token` events, then `done` (or `error`)."""
    history = [m.model_dump() for m in req.history]

    def events():
        for ev in rag.stream_answer(req.question, history):
            yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
