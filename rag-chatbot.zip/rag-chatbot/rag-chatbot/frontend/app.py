import json
import os

import requests
import streamlit as st

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

st.set_page_config(page_title="KB Chatbot", page_icon="💬", layout="wide")
st.title("💬 Knowledge Base Chatbot")
st.caption("Documents can be in Spanish — answers are always in English.")


# ---------- sidebar: document management ----------
with st.sidebar:
    st.header("Documents")
    uploads = st.file_uploader(
        "Upload PDF / DOCX / TXT / MD / HTML",
        type=["pdf", "docx", "txt", "md", "html", "htm"],
        accept_multiple_files=True,
    )
    if st.button("Index uploaded files", disabled=not uploads, type="primary"):
        with st.spinner("Chunking and embedding…"):
            try:
                r = requests.post(
                    f"{BACKEND_URL}/ingest",
                    files=[("files", (u.name, u.getvalue())) for u in uploads],
                    timeout=600,
                )
                r.raise_for_status()
                for res in r.json():
                    if res["ok"]:
                        st.success(f"{res['source']}: {res['chunks']} chunks")
                    else:
                        st.error(f"{res['source']}: {res['error']}")
            except requests.RequestException as e:
                st.error(f"Backend error: {e}")

    st.divider()
    try:
        docs = requests.get(f"{BACKEND_URL}/documents", timeout=10).json()
    except requests.RequestException:
        docs = []
        st.warning(f"Backend not reachable at {BACKEND_URL}")
    st.subheader(f"Indexed ({len(docs)})")
    for d in docs:
        c1, c2 = st.columns([5, 1])
        c1.write(f"{d['source']} · {d['chunks']}")
        if c2.button("🗑", key=f"del-{d['source']}", help="Remove from index"):
            requests.delete(f"{BACKEND_URL}/documents/{d['source']}", timeout=30)
            st.rerun()

    if st.button("Clear chat"):
        st.session_state.messages = []
        st.rerun()


# ---------- chat ----------
if "messages" not in st.session_state:
    st.session_state.messages = []


def render_sources(sources: list[dict]):
    if not sources:
        return
    with st.expander(f"Sources ({len(sources)})"):
        for s in sources:
            page = f", p.{s['page']}" if s.get("page") else ""
            st.markdown(f"**[{s['n']}] {s['source']}{page}** — similarity {s['score']}")
            st.caption(s["text"][:500] + ("…" if len(s["text"]) > 500 else ""))


for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])
        render_sources(m.get("sources", []))


def stream_chat(question: str, history: list[dict], sink: dict):
    """Generator of answer tokens for st.write_stream; stashes sources/errors in `sink`."""
    with requests.post(
        f"{BACKEND_URL}/chat/stream",
        json={"question": question, "history": history},
        stream=True,
        timeout=300,
    ) as r:
        r.raise_for_status()
        r.encoding = "utf-8"
        for line in r.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data: "):
                continue
            ev = json.loads(line[6:])
            if ev["type"] == "sources":
                sink["sources"] = ev["sources"]
            elif ev["type"] == "token":
                yield ev["text"]
            elif ev["type"] == "error":
                sink["error"] = ev["message"]
            elif ev["type"] == "done":
                break


if question := st.chat_input("Ask a question about your documents…"):
    history = [{"role": m["role"], "content": m["content"]} for m in st.session_state.messages]
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        sink: dict = {}
        try:
            answer = st.write_stream(stream_chat(question, history, sink))
        except requests.RequestException as e:
            answer = ""
            sink["error"] = str(e)
        if sink.get("error"):
            st.error(sink["error"])
        render_sources(sink.get("sources", []))

    if answer:
        st.session_state.messages.append(
            {"role": "assistant", "content": answer, "sources": sink.get("sources", [])}
        )
