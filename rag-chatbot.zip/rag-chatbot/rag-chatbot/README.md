# Spanish-KB RAG Chatbot

Ask questions in English about Spanish PDFs / knowledge-base docs and get streamed English answers with citations.

- **Backend:** FastAPI, local persistent ChromaDB, `gpt-4.1-mini` + `text-embedding-ada-002`
- **Frontend:** Streamlit chat UI (token streaming, source viewer, upload/delete documents)
- **Formats:** PDF, DOCX, TXT, MD, HTML

## Run

```bash
# 1. Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../env.example .env        # then fill in your key(s)
uvicorn app.main:app --reload --port 8000

# 2. Frontend (new terminal)
cd frontend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py          # set BACKEND_URL if the API isn't on localhost:8000
```

Then upload documents in the sidebar, click **Index uploaded files**, and ask away.

OpenAI vs Azure OpenAI: set `OPENAI_API_KEY`, **or** set `AZURE_OPENAI_API_KEY` + `AZURE_OPENAI_ENDPOINT`
(then `CHAT_MODEL` / `EMBEDDING_MODEL` must be your Azure *deployment names*).

## How it works

```
Upload ─► extract text ─► chunk (1000 chars, 150 overlap) ─► ada-002 embeddings ─► ChromaDB (./chroma_db)

Question (EN) ─► gpt-4.1-mini rewrites into: standalone English question + Spanish search query
              ─► embed both ─► Chroma top-k (merged, best distance wins)
              ─► gpt-4.1-mini answers in English from the Spanish excerpts, citing [n]  ─► SSE stream ─► Streamlit
```

Design choices worth knowing:

- **Cross-lingual retrieval:** ada-002 is only loosely multilingual, so English-to-Spanish matching is weaker than
  Spanish-to-Spanish. The query is therefore also searched in Spanish (one cheap LLM call), which noticeably improves recall.
- **English output** is enforced in the system prompt; Spanish official terms are kept with an English gloss.
- **Follow-up questions** work: the last 6 turns are used to turn "and what about for minors?" into a standalone query.
- Re-uploading a file with the same name **replaces** it in the index.
- Streaming uses Server-Sent Events from `POST /chat/stream` (`sources` → `token`… → `done`/`error`).

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/ingest` | multipart `files` – index documents |
| GET | `/documents` | list indexed documents + chunk counts |
| DELETE | `/documents/{source}` | remove a document |
| POST | `/chat/stream` | `{question, history[]}` → SSE stream |
| GET | `/health` | liveness |

## Limitations

- **Scanned/image-only PDFs** have no text layer and are rejected ("No extractable text"). Add OCR (e.g. Azure Document Intelligence) if you have these.
- CORS is open (`*`) and there is no auth — fine locally, tighten before exposing it.
- Tables in PDFs are extracted as flat text.
